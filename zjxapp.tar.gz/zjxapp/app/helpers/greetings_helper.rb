module GreetingsHelper
end
