class HighScore < ActiveRecord::Base
end
